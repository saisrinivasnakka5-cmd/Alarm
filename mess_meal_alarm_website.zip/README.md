# Mess Meal Alarm

A responsive Flask website for breakfast, lunch and dinner reminders.

## Features
- Responsive HTML/CSS frontend
- Python Flask backend
- SQLite database stores meal times and enabled/disabled status
- Live clock and countdown to the next meal
- Browser notification permission button and on-page alarm

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (optional but recommended):

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the website:

   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

The database file `mess_alarm.db` is created automatically.

## Important alarm note
Keep the website open for reminders. Browsers and phones may pause background tabs, and notifications generally require permission and a secure context (localhost or HTTPS). For dependable alarms when the site is closed, a native app or push-notification service is needed.

## Deploy
This is a Python Flask app, so deploy it to a Python host such as Render rather than GitHub Pages. Use `pip install -r requirements.txt` as the build command and `gunicorn app:app` as the start command (the included requirements install `gunicorn`). For persistent data, configure a persistent disk or use a managed database. GitHub Pages only hosts static files and cannot run `app.py`.
